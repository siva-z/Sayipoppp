from django.apps import AppConfig


class BgmiConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bgmi'
