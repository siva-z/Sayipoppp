from django.urls import path
from . import views
urlpatterns=[
    path('members/',views.members,name='members'),
    path('',views.home_page,name='index'),
    path('about/',views.about,name='about'),
    path('register',views.register),
    path('login',views.login_user)
]
