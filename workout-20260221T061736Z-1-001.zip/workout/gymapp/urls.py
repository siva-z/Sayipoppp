from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name="index"),
    path('login/', views.login_view, name="login"),
    path('register/', views.register_view, name="register"),
    path('admin-dashboard/', views.admin_dashboard, name="admin_dashboard"),
    path('my-workouts/', views.my_workouts, name="my_workouts"),
    path('logout/', views.logout_view, name="logout"),
    path('dashboard/', views.user_dashboard, name="user_dashboard"),
    path('workout/<int:workout_id>/<str:status>/',views.update_workout_status,name="update_workout_status"),
    path('admin-dashboard/user-workouts/<int:user_id>/',views.view_user_workouts,name="view_user_workouts"),



]
