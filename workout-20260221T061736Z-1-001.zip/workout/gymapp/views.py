from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.contrib.auth.models import User
from .models import WorkoutAssignment
from datetime import date
from django.contrib.auth.decorators import user_passes_test


def index(request):
    return render(request, "index.html")

def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")

        user = authenticate(username=username, password=password)

        if user is None:
            messages.error(request, "Invalid username or password")
            return render(request, "login.html")

        login(request, user)

        if user.is_superuser:
            return redirect("admin_dashboard")

       
        return redirect("user_dashboard")

    return render(request, "login.html")

def register_view(request):

    if request.method == "POST":

        username = request.POST.get("username")
        name = request.POST.get("name")
        email = request.POST.get("email")
        password = request.POST.get("password")

        # Prevent duplicate usernames
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already taken")
            return redirect("register")

        # Prevent duplicate emails (optional)
        if User.objects.filter(email=email).exists():
            messages.error(request, "Email already registered")
            return redirect("register")

        user = User.objects.create_user(
            username=username,
            email=email,
            password=password
        )

        # Save full name if given
        if name:
            user.first_name = name
            user.save()

        
        return redirect("login")

    return render(request, "register.html")

from django.contrib.auth import logout

def logout_view(request):
    logout(request)
    return redirect("login")



@user_passes_test(lambda u: u.is_superuser)
def admin_dashboard(request):

    users = User.objects.filter(is_superuser=False)
    assignments = WorkoutAssignment.objects.order_by('-created_at')

    if request.method == "POST":
        user_id = request.POST.get("user_id")
        workout_name = request.POST.get("workout_name")
        description = request.POST.get("description")
        workout_date = request.POST.get("date")

        user = User.objects.get(id=user_id)

        WorkoutAssignment.objects.create(
            user=user,
            workout_name=workout_name,
            description=description,
            date=workout_date,
            assigned_by=request.user
        )

        messages.success(request, f"Workout assigned to {user.username}")
        return redirect("admin_dashboard")

    context = {
        "users": users,
        "assignments": assignments
    }

    return render(request, "admin_dashboard.html", context)


from django.contrib.auth.decorators import login_required

@login_required
def my_workouts(request):
    workouts = WorkoutAssignment.objects.filter(
        user=request.user
    ).order_by('-date')

    return render(request, "my_workouts.html", {
        "workouts": workouts
    })


@login_required
def user_dashboard(request):
    workouts = WorkoutAssignment.objects.filter(
        user=request.user
    ).order_by('-date')

    return render(request, "user_dashboard.html", {
        "workouts": workouts
    })

@login_required
def update_workout_status(request, workout_id, status):
    workout = get_object_or_404(
        WorkoutAssignment,
        id=workout_id,
        user=request.user  # security — only own workout
    )

    allowed = ["Pending", "In Progress", "Completed"]

    if status in allowed:
        workout.status = status
        workout.save()
        messages.success(request, f"Workout marked as {status}")

    return redirect("user_dashboard")
from django.contrib.auth.decorators import user_passes_test

@user_passes_test(lambda u: u.is_superuser)
def view_user_workouts(request, user_id):
    user = get_object_or_404(User, id=user_id)

    workouts = WorkoutAssignment.objects.filter(
        user=user
    ).order_by('-date')

    return render(request, "my_workouts.html", {
        "selected_user": user,
        "workouts": workouts
    })
